package java.sql;

public class Connection {

}
